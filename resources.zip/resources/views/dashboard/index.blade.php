@extends('layouts.app_logged')

@section('sub_content')
	index
@endsection