<ul class="menu-lateral">
	<li>
		<a href="{{ route('inicio') }}">
			<i class="fas fa-home"></i> Inicio
		</a>
	</li>
	<li>
		<a href="{{ route('clientes.lista') }}">
			<i class="fas fa-users"></i> Contáctos
		</a>
	</li>
	<li>
		<a href="{{ route('seguimientos.lista') }}">
			<i class="fas fa-list-ul"></i> Seguimiento
		</a>
	</li>
	@can('usuarios.lista')
		<li>
			<a href="{{ route('usuarios.lista') }}">
				<i class="fas fa-key"></i> Usuarios
			</a>
		</li>
	@endcan
</ul>