{{ Form::open(['url' => $url, 'method' => 'get']) }}
	{{ Form::token() }}
	<div class="row align-center align-items-center">
		<div class="col-12 col-md-11">
			{{ Form::text('query', $query, ['placeholder' => $placeholder]) }}
		</div>
		<div class="col-12 col-md-1">
			{!! Form::button('<i class="fas fa-search"></i>', ['type' => 'submit', 'class' => 'btn primary']) !!}
		</div>
	</div>
{{ Form::close() }}