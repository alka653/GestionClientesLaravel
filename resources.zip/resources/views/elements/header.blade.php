<header>
	<nav class="container">
		<div class="complete">
			<ul class="nav">
				<li class="nav-item">
					<a href="#">Perfil</a>
				</li>
				<li class="nav-item">
					<a href="{{ route('usuarios.salir') }}">Cerrar sesión</a>
				</li>
			</ul>
		</div>
		<div class="complete padding-top">
			<h1 class="no-margin">
				Agenda Ministerio
			</h1>
			<small>{{ Auth::user()->persona->nombre }} {{ Auth::user()->persona->apellido }}</small>
		</div>
		<div class="padding-top"></div>
	</nav>
</header>