@extends('layouts.app_logged')

@section('sub_title', 'Agregar contácto')

@section('sub_content')
	{{ Form::model($persona, ['route' => $route, 'method' => $method, 'enctype' => 'multipart/form-data']) }}
		<div class="form-control {{ $errors->has('nombre') ? 'form-error': '' }}">
			{{ Form::label('nombre', 'Nombre del contacto', ['class' => 'label-required']) }}
			{{ Form::text('nombre', null, ['required']) }}
			{!! $errors->first('nombre', '<p class="help-block">:message</p>') !!}
		</div>
		<div class="form-control {{ $errors->has('apellido') ? 'form-error': '' }}">
			{{ Form::label('apellido', 'Apellido del contacto', ['class' => 'label-required']) }}
			{{ Form::text('apellido', null, ['required']) }}
			{!! $errors->first('apellido', '<p class="help-block">:message</p>') !!}
		</div>
		<div class="form-control {{ $errors->has('email') ? 'form-error': '' }}">
			{{ Form::label('email', 'Correo del contacto', ['class' => 'label-required']) }}
			{{ Form::email('email', null, ['required']) }}
			{!! $errors->first('email', '<p class="help-block">:message</p>') !!}
		</div>
		<div class="form-control {{ $errors->has('numero_telefonico') ? 'form-error': '' }}">
			{{ Form::label('numero_telefonico', 'Número telefónico', ['class' => 'label-required']) }}
			{{ Form::text('numero_telefonico', null, ['required', 'class' => 'only-number']) }}
			{!! $errors->first('numero_telefonico', '<p class="help-block">:message</p>') !!}
		</div>
		<div class="form-control {{ $errors->has('dependencia') ? 'form-error': '' }}">
			{{ Form::label('dependencia', 'Dependencia del contacto', ['class' => 'label-required']) }}
			{{ Form::text('dependencia', null, ['required']) }}
			{!! $errors->first('dependencia', '<p class="help-block">:message</p>') !!}
		</div>
		<div class="form-control {{ $errors->has('Referido') ? 'form-error': '' }}">
			{{ Form::label('Referido', 'Referido del contacto') }}
			{{ Form::text('Referido', null) }}
			{!! $errors->first('Referido', '<p class="help-block">:message</p>') !!}
		</div>
		<div class="form-control {{ $errors->has('palabra_clave') ? 'form-error': '' }}">
			{{ Form::label('palabra_clave', 'Palabras claves') }}
			{{ Form::text('palabra_clave', null) }}
			{!! $errors->first('palabra_clave', '<p class="help-block">:message</p>') !!}
		</div>
		<div class="form-control">
			{{ Form::label('foto', 'Foto del contacto') }}
			{{ Form::file('foto', ['accept' => 'image/*']) }}
		</div>
		<div class="form-control align-center">
			{!! Form::button('Enviar', ['type' => 'submit', 'class' => 'btn primary']) !!}
		</div>
	{{ Form::close() }}
@endsection